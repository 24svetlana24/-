﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bd10
{
    /// <summary>
    /// Логика взаимодействия для SotrudnikiWindow.xaml
    /// </summary>
    public partial class SotrudnikiWindow : Window
    {
        bd10Entities1 Add { get; set; }
        public SotrudnikiWindow()
        {
            InitializeComponent();
            Loader();
        }
        public void Loader()
        {
            Add = new bd10Entities1();
            Sotrudniki.ItemsSource = Add.Sotrudniki.ToList();
        }
        private void qeq(object sender, RoutedEventArgs e) /*Кнопка  Удаления*/
        {
            Add = new bd10Entities1();
            Sotrudniki item = Sotrudniki.SelectedItem as Sotrudniki;
            try
            {
                Sotrudniki ser = Add.Sotrudniki.Where(c => c.id == item.id).Single();
                Add.Sotrudniki.Remove(ser);
                Add.SaveChanges();

                MessageBox.Show("Данные успешно удалены");
                refreshdatagrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void refreshdatagrid() /*обновление таблицы*/
        {
            Add = new bd10Entities1();
            Sotrudniki.ItemsSource = Add.Sotrudniki.ToList();
            Sotrudniki.Items.Refresh();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window1 f1 = new Window1();
            f1.Show();
            Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

            //AddSotrudnikiWindow f5 = new AddSotrudnikiWindow();
            AddSotrudnikiWindow addSotrudnikiWindow = new AddSotrudnikiWindow();
            addSotrudnikiWindow.Owner = this;
            addSotrudnikiWindow.Show();
            //f5.Show();

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e) //Поиск
        {
            var input = (sender as TextBox).Text.ToLower();
            if (!(String.IsNullOrEmpty(input)))
            {
                int resultCount = Add.Sotrudniki.Count(x => x.surname.Contains(input));
                Sotrudniki.ItemsSource = Add.Sotrudniki.Where(x => x.surname.Contains(input)).ToList();
                Title = $"База данных | Поиск: {input} | Результатов: {resultCount} из {Add.Sotrudniki.ToList().Count()}";
            }
            else
                ReadData();
        }
        public void ReadData()
        {
            Add = new bd10Entities1();
            Sotrudniki.ItemsSource = Add.Sotrudniki.ToList();
            Title = $"База данных";
        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            var input = (sender as TextBox).Text.ToLower();
            if (!(String.IsNullOrEmpty(input)))
            {
                int resultCount = Add.Sotrudniki.Count(x => x.Dol.name.Contains(input));
                Sotrudniki.ItemsSource = Add.Sotrudniki.Where(x => x.Dol.name.Contains(input)).ToList();
                Title = $"База данных | Поиск: {input} | Результатов: {resultCount} из {Add.Sotrudniki.ToList().Count()}";
            }
            else
                ReadData();
        }

        private void SaveChangesButton_Click(object sender, RoutedEventArgs e)
        {
            Sotrudniki user = new Sotrudniki();
            user = Sotrudniki.SelectedItem as Sotrudniki;

            user.surname = a1.Text;
            user.name = a2.Text;
            user.middle_name = a3.Text;
            //user.Dol = (b1.SelectedItem as Dol).id;
            user.date = c1.SelectedDate;
            user.number = a5.Text;
            //user.Gender = (b2.SelectedItem as Gender).id;

            MessageBox.Show("ИБП успешно добавлен в базу!");
            Add.SaveChanges();
            Sotrudniki.ItemsSource = Add.Sotrudniki.ToList();

            b1.SelectedValue = -1;
            b2.SelectedValue = -1;
        }
    }
    
}

